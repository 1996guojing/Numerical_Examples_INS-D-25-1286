clc;
clear;
close all;
%% CN parameters for 7 nodes

%system parameters
RR = 1000;
CC1 = 0.000111;
CC2 = 0.000010;
LL = 7000;
a = 1/(RR*CC1);
b = 1/(LL*CC2);
m0 = -1/7;
m1 = 2/7;
N =5;

%isolate node

A0 = [-a*m1 a 0;
         1 -1 1;
         0 -b 0];
n = length(A0);

%CN
A1 =[-a*m1+0.2 a+0.1 0;
         1 -1 1;
         0 -b+0.2 0];
A2 =[-a*m1-0.5 a-0.1 0;
         1 -1 1;
         0 -b-0.2 0];     
A3 =[-a*m1+0.1 a 0;
         1 -1-0.1 1;
         0 -b+0.1 0];
A4 =[-a*m1-0.1 a 0;
         1 -1+0.1 1;
         0 -b-0.1 0];
A5 =[-a*m1-0.1 a-1 0;
         1 -1 1;
         0 -b-1 0];
     
Lam1 = [abs(a*(m1-m0)-1) 0 0
            0 0 0
            0 0 0];   
Lam2 = [abs(a*(m1-m0)+1) 0 0
            0 0 0
            0 0 0]; 
Lam3 = [abs(a*(m1-m0)-0.5) 0 0
            0 0 0
            0 0 0];
Lam4 = [abs(a*(m1-m0)-0.5) 0 0
            0 0 0
            0 0 0]; 
Lam5 = [abs(a*(m1-m0)-1) 0 0
            0 0 0
            0 0 0];         

A = blkdiag(A1,A2,A3,A4,A5);     
A_=blkdiag(A0,A0,A0,A0,A0);
Lam_=blkdiag(Lam1,Lam2,Lam3,Lam4,Lam5);
Lam_con=2;

CC = eye(n);
C1 = eye(n);
C2 = eye(n);
C3 = eye(n);
C4 = eye(n);
C5 = eye(n);
C6 = eye(n);
C = 0.5*blkdiag(C1,C2,C3,C4,C5);
[m,~] = size(C1);

Gama = eye(n);
lota = 0.01;
W = [-2 1 1 0 0 
        1 -2 1 0 0 
        1 1 -3 1 0 
        0 0 1 -2 1 
        0 0 0 1 -1 ];
      
WG1 = lota*kron(W,Gama);

%triggering patameters
h = 0.01;

%Lyapunov parameters
alpha1 = 7;
alpha2 = 0.7; 
alpha3 = 0.1;
gamma = 1;
h_ = -log(alpha2)/alpha1-0.001;
codition_1 = log(alpha2)/h_+alpha1;

 %% slove LMIs
setlmis([])
for i=1:N
    [p{i},~,P_{i}] = lmivar(1,[n 1]);
    [y1{i},~,Y1_{i}] = lmivar(2,[n n]);
    [y2{i},~,Y2_{i}] = lmivar(2,[n n]);
end

P = lmivar(3, blkdiag(P_{:}));
Y1 = lmivar(3, blkdiag(Y1_{:}));
Y2 = lmivar(3, blkdiag(Y2_{:}));

EP1 = lmivar(1,[n*N 1]);
EP2 = lmivar(1,[n*N 1]);

lmiterm([1 1 1 P],A,1,'s');
lmiterm([1 1 1 P],WG1,1,'s');
lmiterm([1 1 1 P],-alpha1,1);
lmiterm([1 1 1 EP2],Lam_',Lam_);
lmiterm([1 1 4 P],1,1);
lmiterm([1 1 5 P],1,1);
% % % % 
lmiterm([1 2 2 P],A,1,'s');
lmiterm([1 2 2 P],WG1,1,'s');
lmiterm([1 2 2 P],-alpha1,1);
lmiterm([1 2 2 EP2],Lam_',Lam_);
lmiterm([1 2 6 P],1,1);
% % % 
lmiterm([1 3 3 P],A,1,'s');
lmiterm([1 3 3 P],WG1,1,'s');
lmiterm([1 3 3 P],-alpha1,1);
lmiterm([1 3 3 EP2],Lam_',Lam_);
lmiterm([1 3 7 P],1,1);
% % 
lmiterm([1 4 4 EP1],-1,1);
lmiterm([1 5 5 EP2],-1,1);
lmiterm([1 6 6 EP2],-1,1);
lmiterm([1 7 7 EP2],-1,1); 
% % % 
lmiterm([2 1 1 P],1,1);
lmiterm([2 1 1 Y1],1,1,'s');
lmiterm([2 1 1 P],-alpha2,1);
lmiterm([2 1 2 Y1],-1,1);
lmiterm([2 1 4 Y1],-1,1);
lmiterm([2 1 5 -Y1],1,1);
lmiterm([2 1 7 -Y1],1,1);
% 
lmiterm([2 2 2 P],1,1);
lmiterm([2 2 2 P],-alpha2,1);
lmiterm([2 2 2 Y2],-1,C,'s');
lmiterm([2 2 3 Y2],1,C);
lmiterm([2 2 5 -Y1],-1,1);
lmiterm([2 2 6 -Y2],-C',1);
lmiterm([2 2 7 -Y1],-1,1);
% 
lmiterm([2 3 3 P],-alpha2,1);
lmiterm([2 3 6 -Y2],C',1);
% 
lmiterm([2 4 4 0],-alpha3*eye(n*N));
lmiterm([2 4 5 -Y1],-1,1);
lmiterm([2 4 7 -Y1],-1,1);
lmiterm([2 4 7 P],1,1);
% 
lmiterm([2 5 5 P],-1,1);
% 
lmiterm([2 6 6 P],-1,1);
% 
lmiterm([2 7 7 P],-1,1);

lmiterm([-3 1 1 P],1,1);

lmiterm([-5 1 1 EP1],1,1);
lmiterm([-6 1 1 EP2],1,1);
lmiterm([9 1 1 EP1],1,1);
lmiterm([9 1 1 0],-0.001*eye(n*N));

lmis = getlmis;
[tmin,xfeas]=feasp(lmis);
P=dec2mat(lmis,xfeas,P);

Y1=dec2mat(lmis,xfeas,Y1);
Y2=dec2mat(lmis,xfeas,Y2);
EP1=dec2mat(lmis,xfeas,EP1);
K = P\Y1;
L = P\Y2;
%%

t_max = 70;
eps1 = 1;
eps2 = 1;
eps3 = 0.1;
eps4 = 0.3;

%% initialization

x(:,1:2) = 0.5*rand(N*n,2); % observer
x_(:,1:2) =0.5* rand(N*n,2); % observer
x_a(:,1:2) = 0.5*rand(N*n,2); %encoding state
phi(:,1:2) = 0.5*rand(n,2); %isolate node
phi_ = zeros(N*n,2);
x_un(:,1:2) = x(:,1:2);
for i_p = 1:1:N
    phi_(n*(i_p-1)+1:n*i_p,1:2) = phi(:,1:2);
end

eta1(:,1:2) = x(:,1:2) - phi_(:,1:2); %synchronization error
eta2(:,1:2) = x(:,1:2) - x_(:,1:2); %observer error
eta1_norm(:,1:2) = norm(eta1(:,1:2)).*norm(eta1(:,1:2)); 
x_d(:,1:2) = x_a(:,1:2); %decoding state
x_c(:,1:2) = x_a(:,1:2); %predictor of decoding state

e_a(:,1:2) =  x_a(:,1:2) - phi_(:,1:2); %encoding error
e_d(:,1:2) =  x_d(:,1:2) - phi_(:,1:2); %decoding error
e(:,1:2) = x_(:,1:2) - x_a(:,1:2);
e_t(:,1:2) = x_(:,1:2) - phi_(:,1:2);
j = 2;
d = 0.01;
tk=zeros(N,j); %triggering time
u=zeros(n*N,j);
k_node  = ones(1,N); %triggering number time 
k_node_e  = ones(N,j); %triggering number time 
eta_i(:,1:2) = ones(N,2);

%% bit-rate constraints
Rall = 150;
Ri =floor(Rall/N);
Rin = floor(Ri/n);

lam_p = min(eig(P));
lam_ep = max(eig(EP1));
sgm = 1;
A_e = A - A_;
theta1 = lam_ep*(max(eig(A_e))*sgm+N^0.5*max(Lam_con))^2;
theta2 = alpha3*n*N*(0.9/(2^(Rin-1)))^2;
boundness = (alpha1*theta2*exp(-(log(alpha2)+alpha1*h))...
                     +theta1)/(lam_p*alpha1*(exp(-(log(alpha2)+alpha1*h))-1));
%% numerical simulation
for i = 0:h:t_max
    t(j) = i;
    eta1_norm(:,j) = norm(eta1(:,j)).*norm(eta1(:,j));
    fx1(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x(1,j)+1)-abs(x(1,j)-1));0;0];%CD nonlinear
    fx2(:,j)=[(a*(m1-m0)+1)*0.5*(abs(x(4,j)+1)-abs(x(4,j)-1));0;0];
    fx3(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x(7,j)+1)-abs(x(7,j)-1));0;0];
    fx4(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x(10,j)+1)-abs(x(10,j)-1));0;0];
    fx5(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x(13,j)+1)-abs(x(13,j)-1));0;0];
    f(:,j) = [fx1(:,j);fx2(:,j);fx3(:,j);fx4(:,j);fx5(:,j)];
    
    f_x1(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x_(1,j)+1)-abs(x_(1,j)-1));0;0];%observer nonlinear
    f_x2(:,j)=[(a*(m1-m0)+1)*0.5*(abs(x_(4,j)+1)-abs(x_(4,j)-1));0;0];
    f_x3(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x_(7,j)+1)-abs(x_(7,j)-1));0;0];
    f_x4(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x_(10,j)+1)-abs(x_(10,j)-1));0;0];
    f_x5(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x_(13,j)+1)-abs(x_(13,j)-1));0;0];
    f_(:,j) = [f_x1(:,j);f_x2(:,j);f_x3(:,j);f_x4(:,j);f_x5(:,j)];
    
    f_x_a1(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x_a(1,j)+1)-abs(x_a(1,j)-1));0;0]; %enconding nonlinear
    f_x_a2(:,j)=[(a*(m1-m0)+1)*0.5*(abs(x_a(4,j)+1)-abs(x_a(4,j)-1));0;0]; 
    f_x_a3(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x_a(7,j)+1)-abs(x_a(7,j)-1));0;0]; 
    f_x_a4(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x_a(10,j)+1)-abs(x_a(10,j)-1));0;0]; 
    f_x_a5(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x_a(13,j)+1)-abs(x_a(13,j)-1));0;0]; 
    f_x_a(:,j) = [f_x_a1(:,j);f_x_a2(:,j);f_x_a3(:,j);f_x_a4(:,j);f_x_a5(:,j)];
    
    f_x_d1(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x_d(1,j)+1)-abs(x_d(1,j)-1));0;0]; %deconding nonlinear
    f_x_d2(:,j)=[(a*(m1-m0)+1)*0.5*(abs(x_d(4,j)+1)-abs(x_d(4,j)-1));0;0]; 
    f_x_d3(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x_d(7,j)+1)-abs(x_d(7,j)-1));0;0]; 
    f_x_d4(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x_d(10,j)+1)-abs(x_d(10,j)-1));0;0]; 
    f_x_d5(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x_d(13,j)+1)-abs(x_d(13,j)-1));0;0];
    f_x_d(:,j) = [f_x_d1(:,j);f_x_d2(:,j);f_x_d3(:,j);f_x_d4(:,j);f_x_d5(:,j)];
    
    f_x_un1(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x_un(1,j)+1)-abs(x_un(1,j)-1));0;0]; %predictor nonlinear
    f_x_un2(:,j)=[(a*(m1-m0)+1)*0.5*(abs(x_un(4,j)+1)-abs(x_un(4,j)-1));0;0]; 
    f_x_un3(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x_un(7,j)+1)-abs(x_un(7,j)-1));0;0]; 
    f_x_un4(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(x_un(10,j)+1)-abs(x_un(10,j)-1));0;0]; 
    f_x_un5(:,j)=[(a*(m1-m0)-1)*0.5*(abs(x_un(13,j)+1)-abs(x_un(13,j)-1));0;0];
    f_x_un(:,j)=[f_x_un1(:,j);f_x_un2(:,j);f_x_un3(:,j);f_x_un4(:,j);f_x_un5(:,j)]; 
    
    f_phi1_1(:,j)=[(a*(m1-m0)-1)*0.5*(abs(phi_(1,j)+1)-abs(phi_(1,j)-1));0;0]; %heterogeneous nonlinear
    f_phi2_1(:,j)=[(a*(m1-m0)+1)*0.5*(abs(phi_(1,j)+1)-abs(phi_(1,j)-1));0;0]; 
    f_phi3_1(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(phi_(1,j)+1)-abs(phi_(1,j)-1));0;0]; 
    f_phi4_1(:,j)=[(a*(m1-m0)-0.5)*0.5*(abs(phi_(1,j)+1)-abs(phi_(1,j)-1));0;0]; 
    f_phi5_1(:,j)=[(a*(m1-m0)-1)*0.5*(abs(phi_(1,j)+1)-abs(phi_(1,j)-1));0;0];
    f_phi_1(:,j)=[f_phi1_1(:,j);f_phi2_1(:,j);f_phi3_1(:,j);f_phi4_1(:,j);f_phi5_1(:,j)]; 
    
    f_phi(:,j)=[a*(m1-m0)*0.5*(abs(phi_(1,j)+1)-abs(phi_(1,j)-1));0;0]; %isolate nonlinear
    f_phi_(:,j)=[f_phi(:,j);f_phi(:,j);f_phi(:,j);f_phi(:,j);f_phi(:,j)]; 
    
    f_eta1(:,j) = f(:,j)-f_phi_(:,j);
    f_eta2(:,j) = f(:,j)-f_(:,j);
    v(:,j) = A_*phi_(:,j) - A*phi_(:,j) + f_phi_(:,j) - f_phi_1(:,j);
    f_e_a(:,j) =   f_x_a(:,j) -f_phi_(:,j);
    f_e_d(:,j) =  f_x_d(:,j) - f_phi_(:,j);
    
    % First, determine whether the trigger has occurred, 
    %then make a distributed judgment on the trigger condition.
    for ii = 0:1:N-1
        %x_c
        temp = k_node_e(ii+1,k_node(ii+1));
        ee(ii+1,j)=norm(e(ii*n+1:ii*n+n,j));
        sigma(ii+1,j) = eps1*exp(eps2*(i-tk(ii+1,temp)));
        PHI1(ii+1,j) = sigma(ii+1,j)*norm(e(ii*n+1:ii*n+n,j))-eps3*norm(x_(ii*n+1:ii*n+n,j))-eta_i(ii+1,j);
%         PHI1(ii+1,j)
        PHI2(ii+1,j) = 1-((i-tk(ii+1,temp))/(h_));
%         PHI2(ii+1,j) PHI1(ii+1,j) >0 || PHI2(ii+1,j)<0
        if PHI1(ii+1,j) >0 || PHI2(ii+1,j)<0
            tk(ii+1,j) = t(j);
            k_node(ii+1) = k_node(ii+1)+1;
            k_node_e(ii+1,k_node(ii+1)) = j;
            if k_node(ii+1) == 1
                tk_1(ii+1) = 1;
            else
                tk_1(ii+1) = k_node_e(ii+1,k_node(ii+1)-1);
            end
            hc(ii*n+1:ii*n+n,j) = dyn_quan_en_test(e(ii*n+1:ii*n+n,j),Rin);
            %x_a
            x_a(ii*n+1:ii*n+n,j) = hc(ii*n+1:ii*n+n,j)+x_a(ii*n+1:ii*n+n,j);
            %x_d
            x_d(ii*n+1:ii*n+n,j) = hc(ii*n+1:ii*n+n,j)+x_d(ii*n+1:ii*n+n,j); 
            %eta1
            eta1(ii*n+1:ii*n+n,j) =  eta1(ii*n+1:ii*n+n,j)...
                                               +K(ii*n+1:ii*n+n,ii*n+1:ii*n+n)*(x_d(ii*n+1:ii*n+n,j)- phi_(ii*n+1:ii*n+n,j)); 
            eta2(ii*n+1:ii*n+n,j) =  eta2(ii*n+1:ii*n+n,j)...
                                               +K(ii*n+1:ii*n+n,ii*n+1:ii*n+n)*(x_d(ii*n+1:ii*n+n,j)- phi_(ii*n+1:ii*n+n,j))...
                                               -L(ii*n+1:ii*n+n,ii*n+1:ii*n+n)*CC*eta2(ii*n+1:ii*n+n,j); 
                                           
            e(ii*n+1:ii*n+n,j) = x_(ii*n+1:ii*n+n,j) - x_a(ii*n+1:ii*n+n,j); %triggering error
            u(ii*n+1:ii*n+n,j) = K(ii*n+1:ii*n+n,ii*n+1:ii*n+n)*(x_d(ii*n+1:ii*n+n,j)- phi_(ii*n+1:ii*n+n,j));
        end        
    end
	%x_a
    x_a(:,j+1) = x_a(:,j) + (A*x_a(:,j)+f_x_a(:,j)+WG1*x_a(:,j))*d;
	%x_d
    x_d(:,j+1) = x_d(:,j) + (A*x_d(:,j)+f_x_d(:,j)+WG1*x_d(:,j))*d;
	%eta1
    eta1(:,j+1) = eta1(:,j) + (A*eta1(:,j)+f_eta1(:,j)+WG1*eta1(:,j)+v(:,j))*d;
	%eta2
    eta2(:,j+1) = eta2(:,j) + (A*eta2(:,j)+f_eta2(:,j)+WG1*eta2(:,j))*d;
    e(:,j+1) = e(:,j) + (A*e(:,j)+(f_(:,j)-f_x_d(:,j))+WG1*e(:,j))*d;
    
    phi_(:,j+1) = phi_(:,j) + (A_*phi_(:,j)+f_phi_(:,j))*d;
    x(:,j+1) = eta1(:,j+1)+phi_(:,j+1);
    x_un(:,j+1) = x_un(:,j) + (A*x_un(:,j)+f_x_un(:,j)+WG1*x_un(:,j))*d;
    x_(:,j+1) = x(:,j+1) - eta2(:,j+1);

    eta_i(:,j+1) = eps4*eta_i(:,j);
    j = j+1;
end

%% figure
%synchronization error
figure(1) 
subplot(3,1,1)
for p = 0:1:N-1
     plot(t,eta1(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$\eta_{1i}(t)$','Interpreter','latex')
legend('$\eta_{11}(t)$','$\eta_{12}(t)$','$\eta_{13}(t)$','$\eta_{14}(t)$','$\eta_{15}(t)$')

subplot(3,1,2)
for p = 0:1:N-1
     plot(t,eta1(p*n+2,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$\eta_{2i}(t)$','Interpreter','latex')
legend('$\eta_{21}(t)$','$\eta_{22}(t)$','$\eta_{23}(t)$','$\eta_{24}(t)$','$\eta_{25}(t)$')

subplot(3,1,3)
 for p = 0:1:N-1
     plot(t,eta1(p*n+n,2:end),'LineWidth',1.5);
     hold on;
 end
ylabel('$\eta_{3i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
legend('$\eta_{31}(t)$','$\eta_{32}(t)$','$\eta_{33}(t)$','$\eta_{34}(t)$','$\eta_{35}(t)$')

%observer error
figure(2) 
subplot(3,1,1)
for p = 0:1:N-1
     plot(t,eta2(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
s1 = legend('$\hat{\eta}_{11}(t)$','$\hat{\eta}_{12}(t)$','$\hat{\eta}_{13}(t)$','$\hat{\eta}_{14}(t)$','$\hat{\eta}_{15}(t)$');
set(s1,'Interpreter','latex')
ylabel('$\hat{\eta}_{1i}(t)$','Interpreter','latex')

subplot(3,1,2)
for p = 0:1:N-1
     plot(t,eta2(p*n+2,2:end),'LineWidth',1.5);
     hold on;
end
s1 = legend('$\hat{\eta}_{21}(t)$','$\hat{\eta}_{22}(t)$','$\hat{\eta}_{23}(t)$','$\hat{\eta}_{24}(t)$','$\hat{\eta}_{25}(t)$');
set(s1,'Interpreter','latex')
ylabel('$\hat{\eta}_{2i}(t)$','Interpreter','latex')

subplot(3,1,3)
 for p = 0:1:N-1
     plot(t,eta2(p*n+n,2:end),'LineWidth',1.5);
     hold on;
 end
ylabel('$\hat{\eta}_{3i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 = legend('$\hat{\eta}_{31}(t)$','$\hat{\eta}_{32}(t)$','$\hat{\eta}_{33}(t)$','$\hat{\eta}_{34}(t)$','$\hat{\eta}_{35}(t)$');
set(s1,'Interpreter','latex')

%triggering error
figure(3) 
subplot(3,1,1)
for p = 0:1:N-1
     plot(t,e(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
s1 = legend('$e_{11}(t)$','$e_{12}(t)$','$e_{13}(t)$','$e_{14}(t)$','$e_{15}(t)$');
set(s1,'Interpreter','latex')
ylabel('$e_{1i}(t)$','Interpreter','latex')

subplot(3,1,2)
 for p = 0:1:N-1
     plot(t,e(p*n+2,2:end),'LineWidth',1.5);
     hold on;
 end
 s1 = legend('$e_{21}(t)$','$e_{22}(t)$','$e_{23}(t)$','$e_{24}(t)$','$e_{25}(t)$');
set(s1,'Interpreter','latex')
ylabel('$e_{2i}(t)$','Interpreter','latex')

subplot(3,1,3)
 for p = 0:1:N-1
     plot(t,e(p*n+n,2:end),'LineWidth',1.5);
     hold on;
 end
 s1 = legend('$e_{31}(t)$','$e_{32}(t)$','$e_{33}(t)$','$e_{34}(t)$','$e_{35}(t)$');
set(s1,'Interpreter','latex')
ylabel('$e_{3i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')

%node state
figure(4)
subplot(n,1,1)
plot(t,phi_(1,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1
     plot(t,x(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{1i}(t)$','Interpreter','latex')
s1 =legend('$\varphi_1(t)$','$x_{11}(t)$','$x_{12}(t)$','$x_{13}(t)$','$x_{14}(t)$','$x_{15}(t)$');
set(s1,'Interpreter','latex')

subplot(n,1,2)
plot(t,phi_(2,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1 
     plot(t,x(p*n+2,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{2i}(t)$','Interpreter','latex')
s1 =legend('$\varphi_2(t)$','$x_{21}(t)$','$x_{22}(t)$','$x_{23}(t)$','$x_{24}(t)$','$x_{25}(t)$');
set(s1,'Interpreter','latex')

subplot(n,1,n)
plot(t,phi_(3,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1 
     plot(t,x(p*n+n,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{3i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 =legend('$\varphi_3(t)$','$x_{31}(t)$','$x_{32}(t)$','$x_{33}(t)$','$x_{34}(t)$','$x_{35}(t)$');
set(s1,'Interpreter','latex')

%state without control 
figure(5)
subplot(n,1,1)
plot(t,phi_(1,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1
     plot(t,x_un(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{1i}(t)$','Interpreter','latex')
s1 =legend('$\varphi_1(t)$','$x_{11}(t)$','$x_{12}(t)$','$x_{13}(t)$','$x_{14}(t)$','$x_{15}(t)$');
set(s1,'Interpreter','latex')

subplot(n,1,2)
plot(t,phi_(2,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1 
     plot(t,x_un(p*n+2,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{2i}(t)$','Interpreter','latex')
s1 =legend('$\varphi_2(t)$','$x_{21}(t)$','$x_{22}(t)$','$x_{23}(t)$','$x_{24}(t)$','$x_{25}(t)$');
set(s1,'Interpreter','latex')

subplot(n,1,3)
plot(t,phi_(3,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1 
     plot(t,x_un(p*n+n,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{3i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 =legend('$\varphi_3(t)$','$x_{31}(t)$','$x_{32}(t)$','$x_{33}(t)$','$x_{34}(t)$','$x_{35}(t)$');
set(s1,'Interpreter','latex')

%the asymptotic upper bound of synchronization error
figure(6)
plot(t,eta1_norm,'LineWidth',1.5);
hold on;
line([0,t_max],[boundness,boundness],'Color','black','linestyle','--');
s1 =legend('$||\tilde{\eta}(t)||_2^2$', 'the asymptotic upper bound of $||\tilde{\eta}(t)||_2^2$');
set(s1,'Interpreter','latex')

%triggering squence
figure(7)
for i_tg = 1:1:N
    i_tg_y = i_tg*ones(size(tk(i_tg,:)));
    plot(tk(i_tg,:),i_tg_y,'o','LineWidth',1);
    hold on;
end
xlabel('$t(s)$','Interpreter','latex')
legend('Node 1','Node 2','Node 3','Node 4','Node 5')

% control signal
figure(8) 
subplot(n,1,1)
 for p = 0:1:N-1
     stem(tk(p+1,:),u(p*n+1,:),'Marker','none','LineWidth',1.5)
     hold on;
 end
ylabel('$u_{1i}(t)$','Interpreter','latex')
s1 = legend('$u_{11}(t)$','$u_{12}(t)$','$u_{13}(t)$','$u_{14}(t)$','$u_{15}(t)$');
set(s1,'Interpreter','latex')

subplot(n,1,2)
 for p = 0:1:N-1
     stem(tk(p+1,:),u(p*n+2,:),'Marker','none','LineWidth',1.5)
     hold on;
 end
ylabel('$u_{2i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 = legend('$u_{21}(t)$','$u_{22}(t)$','$u_{23}(t)$','$u_{24}(t)$','$u_{25}(t)$');
set(s1,'Interpreter','latex')

subplot(n,1,3)
 for p = 0:1:N-1
     stem(tk(p+1,:),u(p*n+3,:),'Marker','none','LineWidth',1.5)
     hold on;
 end
ylabel('$u_{3i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 = legend('$u_{31}(t)$','$u_{32}(t)$','$u_{33}(t)$','$u_{34}(t)$','$u_{35}(t)$');
set(s1,'Interpreter','latex')
