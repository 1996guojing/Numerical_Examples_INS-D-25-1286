clc;
clear;
close all;
%%coupling structure
%%
ss = [];
tt = [];
weights =[];
N = 10;
for i=1:1:N
    for j=i:1:N
        if i ~= j && j-i ~=5 
                ss = [ss i];                
                tt = [tt j];
                weights = [weights 0.2+0.1*(-1)^(j)];
        else
            ss = [ss];
            tt = [tt];
            weights = [weights];
        end
    end
end

names = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H','I','J'};
G = graph(ss, tt, weights, names);

num_nodes = numel(names); % node number
adjacency_matrix = zeros(num_nodes); % Initialize the adjacency matrix
for i = 1:numel(ss)
    u = ss(i); % start
    vv = tt(i); % end
    w = weights(i); % weight of edge
    adjacency_matrix(u, vv) = w; % Undirected graph, so bidirectional assignment is made
    adjacency_matrix(vv, u) = w;
end

A_sparse = adjacency_matrix;

% Convert a sparse matrix to a dense matrix
WW = full(A_sparse);
W = WW;

%Adjust the diagonal elements to meet the dissipative condition
for i = 1:size(W, 1)
    W(i, i) = -sum(W(i, :)); % Assign the negative value of the sum of each row to the diagonal elements.
end
%% CN parameters for 20 nodes
% isolate node
q=1;
gm = 9.81;
J=40;
B = 0.2;
A0 = [-q/J 1/J;-q*(q-B)/J (q-B)/J];
A_ = A0;
n = length(A0);
M0 = 0.1;
L0 = 0.24;
N =10;

% CN 
% Heterogeneity exists in Ai and nonlinear Lami.
Jn = 40*ones(1,N)+rand(1,N);
Mn = 0.1*ones(1,N);
Ln = 0.2*ones(1,N)+0.1*rand(1,N);
Bn = 0.2*ones(1,N)+0.1*rand(1,N);
Lam_ = [];
CC = eye(n);
C = [];
for i_N = 0:1:N-1
    A(i_N*n+1:i_N*n+n,i_N*n+1:i_N*n+n) = [-q/Jn(i_N+1) 1/Jn(i_N+1)
                            -q*(q-Bn(i_N+1))/Jn(i_N+1) (q-Bn(i_N+1))/Jn(i_N+1)];
    A_(i_N*n+1:i_N*n+n,i_N*n+1:i_N*n+n) = A0; 
    %Lipschitz
    Lam_(i_N*n+1:i_N*n+n,i_N*n+1:i_N*n+n) = [0 0;-Mn(i_N+1)*gm*Ln(i_N+1) 0];
    Lam_con(i_N+1) = Mn(i_N+1)*gm*Ln(i_N+1);
    C = blkdiag(C,CC);
end
[m,~] = size(CC);
Gama = eye(n);
lota = 0.01;     
WG1 = lota*kron(W,Gama);
%triggering patameters
h = 0.01;
h_ = 0.89;

%Lyapunov parameters
alpha1 = 0.4;
alpha2 = 0.7; 
alpha3 = 0.01;

codition_1 = log(alpha2)/h_+alpha1;%check 

 %% slove LMIs
setlmis([])
for i=1:N
    [p{i},~,P_{i}] = lmivar(1,[n 1]);
    [y1{i},~,Y1_{i}] = lmivar(2,[n n]);
    [y2{i},~,Y2_{i}] = lmivar(2,[n n]);
end

P = lmivar(3, blkdiag(P_{:}));
Y1 = lmivar(3, blkdiag(Y1_{:}));
Y2 = lmivar(3, blkdiag(Y2_{:}));

EP1 = lmivar(1,[n*N 1]);
EP2 = lmivar(1,[n*N 1]);

lmiterm([1 1 1 P],A,1,'s');
lmiterm([1 1 1 P],WG1,1,'s');
lmiterm([1 1 1 P],-alpha1,1);
lmiterm([1 1 1 EP2],Lam_',Lam_);
lmiterm([1 1 4 P],1,1);
lmiterm([1 1 5 P],1,1);

lmiterm([1 2 2 P],A,1,'s');
lmiterm([1 2 2 P],WG1,1,'s');
lmiterm([1 2 2 P],-alpha1,1);
lmiterm([1 2 2 EP2],Lam_',Lam_);
lmiterm([1 2 6 P],1,1);

lmiterm([1 3 3 P],A,1,'s');
lmiterm([1 3 3 P],WG1,1,'s');
lmiterm([1 3 3 P],-alpha1,1);
lmiterm([1 3 3 EP2],Lam_',Lam_);
lmiterm([1 3 7 P],1,1);

lmiterm([1 4 4 EP1],-1,1);
lmiterm([1 5 5 EP2],-1,1);
lmiterm([1 6 6 EP2],-1,1);
lmiterm([1 7 7 EP2],-1,1); 

lmiterm([2 1 1 P],1,1);
lmiterm([2 1 1 Y1],1,1,'s');
lmiterm([2 1 1 P],-alpha2,1);
lmiterm([2 1 2 Y1],-1,1);
lmiterm([2 1 4 Y1],-1,1);
lmiterm([2 1 5 -Y1],1,1);
lmiterm([2 1 7 -Y1],1,1);

lmiterm([2 2 2 P],1,1);
lmiterm([2 2 2 P],-alpha2,1);
lmiterm([2 2 2 Y2],-1,C,'s');
lmiterm([2 2 3 Y2],1,C);
lmiterm([2 2 5 -Y1],-1,1);
lmiterm([2 2 6 -Y2],-C',1);
lmiterm([2 2 7 -Y1],-1,1);

lmiterm([2 3 3 P],-alpha2,1);
lmiterm([2 3 6 -Y2],C',1);

lmiterm([2 4 4 0],-alpha3*eye(n*N));
lmiterm([2 4 5 -Y1],-1,1);
lmiterm([2 4 7 -Y1],-1,1);
lmiterm([2 4 7 P],1,1);

lmiterm([2 5 5 P],-1,1);

lmiterm([2 6 6 P],-1,1);

lmiterm([2 7 7 P],-1,1);

lmiterm([-3 1 1 P],1,1);

lmiterm([-4 1 1 EP1],1,1);

lmiterm([-5 1 1 EP2],1,1);

lmis = getlmis;
[tmin,xfeas]=feasp(lmis);
P=dec2mat(lmis,xfeas,P);
Y1=dec2mat(lmis,xfeas,Y1);
Y2=dec2mat(lmis,xfeas,Y2);
EP1=dec2mat(lmis,xfeas,EP1);

K = P\Y1;
L = P\Y2;

%%
t_max = 70;
eps1 = 2;
eps2 = 2;
eps3 = 0.1;
eps4 = 0.5;

%% initialization

x(:,1:2) = rand(N*n,2); % observer           
x_(:,1:2) = rand(N*n,2); % observer
x_a(:,1:2) = rand(N*n,2); %encoding state
phi(:,1:2) = rand(n,2); %isolate node
phi_ = zeros(N*n,2);
x_un(:,1:2) = x(:,1:2);
for i_p = 1:1:N
    phi_(n*(i_p-1)+1:n*i_p,1:2) = phi(:,1:2);
end

eta1(:,1:2) = x(:,1:2) - phi_(:,1:2); %synchronization error
eta2(:,1:2) = x(:,1:2) - x_(:,1:2); %observer error
eta1_norm(:,1:2) = norm(eta1(:,1:2)).*norm(eta1(:,1:2)); 
x_d(:,1:2) = x_a(:,1:2); %decoding state
x_c(:,1:2) = x_a(:,1:2); %predictor of decoding state

e_a(:,1:2) =  x_a(:,1:2) - phi_(:,1:2); %encoding error
e_d(:,1:2) =  x_d(:,1:2) - phi_(:,1:2); %decoding error
e(:,1:2) = x_(:,1:2) - x_a(:,1:2);
e_t(:,1:2) = x_(:,1:2) - phi_(:,1:2);
j = 2;
d = 0.01;
tk=zeros(N,j); %triggering time
u=zeros(n*N,j);
k_node  = ones(1,N); %triggering number time 
k_node_e  = ones(N,j); %triggering number time 
eta_i(:,1:2) = ones(N,2);

%% bit-rate constraints
R_all = 120;
Ri =floor(R_all/n);
Rin = floor(Ri/n);

lam_p = min(eig(P));
lam_ep = max(eig(EP1));
sgm = 1;
A_e = A - A_;
theta1 = lam_ep*(max(eig(A_e))*sgm+N^0.5*max(Lam_con))^2;
theta2 = alpha3*n*N*(0.9/(2^(Rin-1)))^2;
boundness = (alpha1*theta2*exp(-(log(alpha2)+alpha1*h))...
                     +theta1)/(lam_p*alpha1*(exp(-(log(alpha2)+alpha1*h))-1));
%% numerical simulation
for i = 0:h:t_max
    t(j) = i;
    eta1_norm(:,j) = norm(eta1(:,j)).*norm(eta1(:,j)); 
    for ii = 0:1:N-1
        f(ii*n+1:ii*n+n,j)=[0;-Mn(ii+1)*gm*Ln(ii+1)*sin(x(ii*n+1,j))];%CD nonlinear
        f_(ii*n+1:ii*n+n,j)=[0;-Mn(ii+1)*gm*Ln(ii+1)*sin(x_(ii*n+1,j))]; %observer nonlinear      
        f_phi_(ii*n+1:ii*n+n,j)=[0;-M0*gm*L0*sin(phi_(ii*n+1,j))]; %isolate nonlinear
        f_phi_1(ii*n+1:ii*n+n,j)=[0;-Mn(ii+1)*gm*Ln(ii+1)*sin(phi_(ii*n+1,j))]; %observer nonlinear
        f_x_a(ii*n+1:ii*n+n,j)=[0;-Mn(ii+1)*gm*Ln(ii+1)*sin(x_a(ii*n+1,j))]; %enconding nonlinear
        f_x_d(ii*n+1:ii*n+n,j)=[0;-Mn(ii+1)*gm*Ln(ii+1)*sin(x_d(ii*n+1,j))]; %deconding nonlinear
        f_x_un(ii*n+1:ii*n+n,j)=[0;-Mn(ii+1)*gm*Ln(ii+1)*sin(x_un(ii*n+1,j))]; %predictor nonlinear                                   
    end
    f_eta1(:,j) = f(:,j)-f_phi_(:,j);
    f_eta2(:,j) = f(:,j)-f_(:,j);
    v(:,j) = A_*phi_(:,j) - A*phi_(:,j) + f_phi_(:,j) - f_phi_1(:,j);
    f_e_a(:,j) =   f_x_a(:,j) -f_phi_(:,j);
    f_e_d(:,j) =  f_x_d(:,j) - f_phi_(:,j);
    % First, determine whether the trigger has occurred, 
    %then make a distributed judgment on the trigger condition.
    for ii = 0:1:N-1
        %x_c
        temp = k_node_e(ii+1,k_node(ii+1));
        ee(ii+1,j)=norm(e(ii*n+1:ii*n+n,j));
        sigma(ii+1,j) = eps1*exp(eps2*(i-tk(ii+1,temp)));
        PHI1(ii+1,j) = sigma(ii+1,j)*norm(e(ii*n+1:ii*n+n,j))-eps3*norm(x_(ii*n+1:ii*n+n,j))-eta_i(ii+1,j);
%         PHI1(ii+1,j)
        PHI2(ii+1,j) = 1-((i-tk(ii+1,temp))/(h_));
%         PHI2(ii+1,j) PHI1(ii+1,j) >0 || PHI2(ii+1,j)<0
        if PHI1(ii+1,j) >0 || PHI2(ii+1,j)<0
            tk(ii+1,j) = t(j);
            k_node(ii+1) = k_node(ii+1)+1;
            k_node_e(ii+1,k_node(ii+1)) = j;
            if k_node(ii+1) == 1
                tk_1(ii+1) = 1;
            else
                tk_1(ii+1) = k_node_e(ii+1,k_node(ii+1)-1);
            end
            hc(ii*n+1:ii*n+n,j) = dyn_quan_en_test(e(ii*n+1:ii*n+n,j),Rin);
            %x_a
            x_a(ii*n+1:ii*n+n,j) = hc(ii*n+1:ii*n+n,j)+x_a(ii*n+1:ii*n+n,j);
            %x_d
            x_d(ii*n+1:ii*n+n,j) = hc(ii*n+1:ii*n+n,j)+x_d(ii*n+1:ii*n+n,j); 
            %eta1
            eta1(ii*n+1:ii*n+n,j) =  eta1(ii*n+1:ii*n+n,j)...
                                               +K(ii*n+1:ii*n+n,ii*n+1:ii*n+n)*(x_d(ii*n+1:ii*n+n,j)- phi_(ii*n+1:ii*n+n,j)); 
            eta2(ii*n+1:ii*n+n,j) =  eta2(ii*n+1:ii*n+n,j)...
                                               +K(ii*n+1:ii*n+n,ii*n+1:ii*n+n)*(x_d(ii*n+1:ii*n+n,j)- phi_(ii*n+1:ii*n+n,j))...
                                               -L(ii*n+1:ii*n+n,ii*n+1:ii*n+n)*CC*eta2(ii*n+1:ii*n+n,j); 
                                           
            e(ii*n+1:ii*n+n,j) = x_(ii*n+1:ii*n+n,j) - x_a(ii*n+1:ii*n+n,j); %triggering error
            u(ii*n+1:ii*n+n,j) = K(ii*n+1:ii*n+n,ii*n+1:ii*n+n)*(x_d(ii*n+1:ii*n+n,j)- phi_(ii*n+1:ii*n+n,j));
        end        
    end
	%x_a
    x_a(:,j+1) = x_a(:,j) + (A*x_a(:,j)+f_x_a(:,j)+WG1*x_a(:,j))*d;
	%x_d
    x_d(:,j+1) = x_d(:,j) + (A*x_d(:,j)+f_x_d(:,j)+WG1*x_d(:,j))*d;
	%eta1
    eta1(:,j+1) = eta1(:,j) + (A*eta1(:,j)+f_eta1(:,j)+WG1*eta1(:,j)+v(:,j))*d;
	%eta2
    eta2(:,j+1) = eta2(:,j) + (A*eta2(:,j)+f_eta2(:,j)+WG1*eta2(:,j))*d;
    e(:,j+1) = e(:,j) + (A*e(:,j)+(f_(:,j)-f_x_d(:,j))+WG1*e(:,j))*d;
    
    phi_(:,j+1) = phi_(:,j) + (A_*phi_(:,j)+f_phi_(:,j))*d;
    x(:,j+1) = eta1(:,j+1)+phi_(:,j+1);
    x_un(:,j+1) = x_un(:,j) + (A*x_un(:,j)+f_x_un(:,j)+WG1*x_un(:,j))*d;
    x_(:,j+1) = x(:,j+1) - eta2(:,j+1);

    eta_i(:,j+1) = eps4*eta_i(:,j);
    j = j+1;
end

%% figure
%synchronization error
figure(1) 
subplot(2,1,1)
for p = 0:1:N-1
     plot(t,eta1(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$\eta_{1i}(t)$','Interpreter','latex')
legend('$\eta_{11}(t)$','$\eta_{12}(t)$','$\eta_{13}(t)$','$\eta_{14}(t)$','$\eta_{15}(t)$','$\eta_{16}(t)$',...
           '$\eta_{17}(t)$','$\eta_{18}(t)$','$\eta_{19}(t)$','$\eta_{110}(t)$')

subplot(2,1,2)
 for p = 0:1:N-1
     plot(t,eta1(p*n+n,2:end),'LineWidth',1.5);
     hold on;
 end
ylabel('$\eta_{2i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
legend('$\eta_{21}(t)$','$\eta_{22}(t)$','$\eta_{23}(t)$','$\eta_{24}(t)$','$\eta_{25}(t)$','$\eta_{26}(t)$',...
           '$\eta_{27}(t)$','$\eta_{28}(t)$','$\eta_{29}(t)$','$\eta_{210}(t)$')

%observer error
figure(2) 
subplot(2,1,1)
for p = 0:1:N-1
     plot(t,eta2(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
s1 = legend('$\hat{\eta}_{11}(t)$','$\hat{\eta}_{12}(t)$','$\hat{\eta}_{13}(t)$','$\hat{\eta}_{14}(t)$','$\hat{\eta}_{15}(t)$',...
    '$\hat{\eta}_{16}(t)$','$\hat{\eta}_{17}(t)$','$\hat{\eta}_{18}(t)$','$\hat{\eta}_{19}(t)$','$\hat{\eta}_{110}(t)$');
set(s1,'Interpreter','latex')
ylabel('$\hat{\eta}_{1i}(t)$','Interpreter','latex')

subplot(2,1,2)
 for p = 0:1:N-1
     plot(t,eta2(p*n+n,2:end),'LineWidth',1.5);
     hold on;
 end
ylabel('$\hat{\eta}_{2i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 = legend('$\hat{\eta}_{21}(t)$','$\hat{\eta}_{22}(t)$','$\hat{\eta}_{23}(t)$','$\hat{\eta}_{24}(t)$','$\hat{\eta}_{25}(t)$',...
    '$\hat{\eta}_{26}(t)$','$\hat{\eta}_{27}(t)$','$\hat{\eta}_{28}(t)$','$\hat{\eta}_{29}(t)$','$\hat{\eta}_{210}(t)$');
set(s1,'Interpreter','latex')

%triggering error
figure(3) 
subplot(2,1,1)
for p = 0:1:N-1
     plot(t,e(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
s1 = legend('$e_{11}(t)$','$e_{12}(t)$','$e_{13}(t)$','$e_{14}(t)$','$e_{15}(t)$','$e_{16}(t)$',...
                   '$e_{17}(t)$','$e_{18}(t)$','$e_{19}(t)$','$e_{110}(t)$');
set(s1,'Interpreter','latex')
ylabel('$e_{1i}(t)$','Interpreter','latex')

subplot(2,1,2)
 for p = 0:1:N-1
     plot(t,e(p*n+n,2:end),'LineWidth',1.5);
     hold on;
 end
 s1 = legend('$e_{21}(t)$','$e_{22}(t)$','$e_{23}(t)$','$e_{24}(t)$','$e_{25}(t)$','$e_{26}(t)$',...
                   '$e_{27}(t)$','$e_{28}(t)$','$e_{29}(t)$','$e_{210}(t)$');
set(s1,'Interpreter','latex')
ylabel('$e_{2i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')

%node state
figure(4)
subplot(n,1,1)
plot(t,phi_(1,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1
     plot(t,x(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{1i}(t)$','Interpreter','latex')
s1 =legend('$\varphi_1(t)$','$x_{11}(t)$','$x_{12}(t)$','$x_{13}(t)$','$x_{14}(t)$','$x_{15}(t)$','$x_{16}(t)$',...
    '$x_{17}(t)$','$x_{18}(t)$','$x_{19}(t)$','$x_{110}(t)$');
set(s1,'Interpreter','latex')

subplot(n,1,2)
plot(t,phi_(2,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1 
     plot(t,x(p*n+2,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{2i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 =legend('$\varphi_2(t)$','$x_{21}(t)$','$x_{22}(t)$','$x_{23}(t)$','$x_{24}(t)$','$x_{25}(t)$','$x_{26}(t)$',...
    '$x_{27}(t)$','$x_{28}(t)$','$x_{29}(t)$','$x_{210}(t)$');
set(s1,'Interpreter','latex')

%state without control 
figure(5)
subplot(n,1,1)
plot(t,phi_(1,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1
     plot(t,x_un(p*n+1,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{1i}(t)$','Interpreter','latex')
s1 =legend('$\varphi_1(t)$','$x_{11}(t)$','$x_{12}(t)$','$x_{13}(t)$','$x_{14}(t)$','$x_{15}(t)$','$x_{16}(t)$',...
    '$x_{17}(t)$','$x_{18}(t)$','$x_{19}(t)$','$x_{110}(t)$');
set(s1,'Interpreter','latex')

subplot(n,1,2)
plot(t,phi_(2,2:end),'k-','LineWidth',1.5);
hold on;
for p = 0:1:N-1 
     plot(t,x_un(p*n+2,2:end),'LineWidth',1.5);
     hold on;
end
ylabel('$x_{2i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 =legend('$\varphi_2(t)$','$x_{21}(t)$','$x_{22}(t)$','$x_{23}(t)$','$x_{24}(t)$','$x_{25}(t)$','$x_{26}(t)$',...
    '$x_{27}(t)$','$x_{28}(t)$','$x_{29}(t)$','$x_{210}(t)$');
set(s1,'Interpreter','latex')

% %the asymptotic upper bound of synchronization error
% figure(6)
% plot(t,eta1_norm,'LineWidth',1.5);
% hold on;
% line([0,t_max],[boundness,boundness],'Color','black','linestyle','--');
% s1 =legend('$||\tilde{\eta}(t)||_2^2$', 'the asymptotic upper bound of $||\tilde{\eta}(t)||_2^2$');
% set(s1,'Interpreter','latex')

%triggering squence
figure(7)
for i_tg = 1:1:N
    i_tg_y = i_tg*ones(size(tk(i_tg,:)));
    plot(tk(i_tg,:),i_tg_y,'o','LineWidth',1);
    hold on;
end
xlabel('$t(s)$','Interpreter','latex')
legend('Node 1','Node 2','Node 3','Node 4','Node 5','Node 6','Node 7','Node 8','Node 9','Node 10')

% control signal
figure(8) 
subplot(n,1,1)
 for p = 0:1:N-1
     stem(tk(p+1,:),u(p*n+1,:),'Marker','none','LineWidth',1.5)
     hold on;
 end
ylabel('$u_{1i}(t)$','Interpreter','latex')
s1 = legend('$u_{11}(t)$','$u_{12}(t)$','$u_{13}(t)$','$u_{14}(t)$','$u_{15}(t)$','$u_{16}(t)$'...
                   ,'$u_{17}(t)$','$u_{18}(t)$','$u_{19}(t)$','$u_{110}(t)$');
set(s1,'Interpreter','latex')
subplot(n,1,2)
 for p = 0:1:N-1
     stem(tk(p+1,:),u(p*n+2,:),'Marker','none','LineWidth',1.5)
     hold on;
 end
ylabel('$u_{2i}(t)$','Interpreter','latex')
xlabel('$t(s)$','Interpreter','latex')
s1 = legend('$u_{21}(t)$','$u_{22}(t)$','$u_{23}(t)$','$u_{24}(t)$','$u_{25}(t)$','$u_{26}(t)$'...
                   ,'$u_{27}(t)$','$u_{28}(t)$','$u_{29}(t)$','$u_{210}(t)$');
set(s1,'Interpreter','latex')